//problem 1
using System;

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Enter first number: ");
            int x = int.Parse(Console.ReadLine());
            Console.Write("Enter second number: ");
            int y = int.Parse(Console.ReadLine());

            int result = x / y;
            Console.WriteLine($"Result: {result}");
        }
        catch (DivideByZeroException)
        {
            Console.WriteLine("Cannot divide by zero.");
        }
        finally
        {
            Console.WriteLine("Operation complete.");
        }
    }
}

//question 1 
/*
The finally block >> ensures that the code inside it always executes, whether an exception occurs or not, to perform cleanup tasks like releasing resources or printing a message.
*/
//problem 2
using System;

class Program
{
    static void TestDefensiveCode(int x, int y)
    {
        if (x <= 0 || y <= 1)
        {
            Console.WriteLine("Both numbers must be positive and Y must be greater than 1.");
        }
        else
        {
            Console.WriteLine("Valid input.");
        }
    }

    static void Main()
    {
        Console.Write("Enter first positive integer: ");
        int x = int.Parse(Console.ReadLine());
        Console.Write("Enter second integer (greater than 1): ");
        int y = int.Parse(Console.ReadLine());

        TestDefensiveCode(x, y);
    }
}

//question 2
/*
 int.TryParse() >>improves program robustness by not throwing an exception when the input is invalid; instead, it returns false, allowing you to handle errors gracefully, unlike int.Parse(), which throws an exception for invalid input.
*/
//problem 3
using System;

class Program
{
    static void Main()
    {
        int? nullableInt = null;
        int result = nullableInt ?? 5; // If nullableInt is null, use 5.
        Console.WriteLine($"Result: {result}");

        if (nullableInt.HasValue)
        {
            Console.WriteLine($"Value: {nullableInt.Value}");
        }
        else
        {
            Console.WriteLine("Value is null.");
        }
    }
}

//question 3
 /*
 Trying to access Value on a null Nullable<T> results in an InvalidOperationException.

*/
 //problem 4
 using System;

class Program
{
    static void Main()
    {
        int[] arr = new int[5];
        try
        {
            arr[10] = 5; // Accessing an out-of-bounds index.
        }
        catch (IndexOutOfRangeException)
        {
            Console.WriteLine("Index out of range.");
        }
    }
}


//question 4
/*
 Checking array bounds before accessing elements is necessary to avoid runtime errors like IndexOutOfRangeException.
 */
 
 //problem 5
 using System;

class Program
{
    static void Main()
    {
        int[,] array = new int[3, 3];
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                Console.Write($"Enter value for position [{i},{j}]: ");
                array[i, j] = int.Parse(Console.ReadLine());
            }
        }

        Console.WriteLine("The 3x3 array is:");
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                Console.Write(array[i, j] + " ");
            }
            Console.WriteLine();
        }
    }
}


 //problem 6
 using System;

#nullable enable

class Program
{
    static void Main()
    {
        string? nullableString = null;
        Console.Write("Enter a value (or leave empty for null): ");
        nullableString = Console.ReadLine();
        
        // Use null-forgiveness operator
        Console.WriteLine(nullableString!.Length);
    }
}


//question 6
/*
Nullable reference types enable the compiler to track whether a reference can be null and provide warnings if there’s a potential NullReferenceException.
*/
 
 //problem 7
 using System;

class Program
{
    static void Main()
    {
        int number = 42;
        object obj = number; // Boxing
        Console.WriteLine($"Boxed object: {obj}");

        try
        {
            int unboxed = (int)obj; // Unboxing
            Console.WriteLine($"Unboxed value: {unboxed}");
        }
        catch (InvalidCastException)
        {
            Console.WriteLine("Invalid cast exception.");
        }
    }
}


//question 7 
/*
Boxing and unboxing incur a performance cost because of the conversion between value types and reference types, and this can be slower than working with value types directly.
*/
 
 //problem 8
 using System;

class Program
{
    static void SumAndMultiply(int x, int y, out int sum, out int product)
    {
        sum = x + y;
        product = x * y;
    }

    static void Main()
    {
        int sum, product;
        SumAndMultiply(5, 10, out sum, out product);
        Console.WriteLine($"Sum: {sum}, Product: {product}");
    }
}


//question 8
/*
Out parameters must be initialized inside the method because they are considered uninitialized when passed to the method.

*/
 
 //problem 9
 using System;

class Program
{
    static void PrintStringMultipleTimes(string str, int times = 5)
    {
        for (int i = 0; i < times; i++)
        {
            Console.WriteLine(str);
        }
    }

    static void Main()
    {
        PrintStringMultipleTimes("Hello", times: 3);
    }
}


//question 9
/*
 Optional parameters must appear at the end of the method's parameter list because they are assigned default values if not explicitly passed.

*/
 
 //problem 10
 using System;

class Program
{
    static void Main()
    {
        int?[] nullableArr = new int?[5];
        nullableArr[2] = 10;

        Console.WriteLine(nullableArr[2]?.ToString() ?? "Value is null");
    }
}


//question 10
/*
 The null propagation operator (?.) safely accesses the property or method, returning null instead of throwing a NullReferenceException if the object is null.

*/
 
 //problem 11
 using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter a day of the week: ");
        string day = Console.ReadLine();
        
        int dayNumber = day switch
        {
            "Monday" => 1,
            "Tuesday" => 2,
            "Wednesday" => 3,
            "Thursday" => 4,
            "Friday" => 5,
            "Saturday" => 6,
            "Sunday" => 7,
            _ => 0
        };
        
        Console.WriteLine($"Day number: {dayNumber}");
    }
}


//question 11
/*
Switch expressions are preferred when you have multiple conditions to check and want a more concise, readable, and functional approach compared to traditional if statements.
*/ 
 
 //problem 12
 using System;

class Program
{
    static int SumArray(params int[] numbers)
    {
        int sum = 0;
        foreach (var num in numbers)
        {
            sum += num;
        }
        return sum;
    }

    static void Main()
    {
        Console.WriteLine(SumArray(1, 2, 3, 4));  // Using individual values
        int[] array = { 5, 6, 7, 8 };
        Console.WriteLine(SumArray(array));  // Using an array
    }
}


//question 12
/*
The params keyword allows passing a variable number of arguments to a method, but it must be the last parameter, and only one params parameter is allowed.
 */
 //=========================================\\
 //======PART2======\\
 //Program to Print Numbers in a Range
 using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter a positive integer: ");
        int number = int.Parse(Console.ReadLine());

        for (int i = 1; i <= number; i++)
        {
            Console.Write(i);
            if (i < number)
                Console.Write(", ");
        }
    }
}
//Program to Display Multiplication Table

using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter an integer: ");
        int number = int.Parse(Console.ReadLine());

        for (int i = 1; i <= 12; i++)
        {
            Console.WriteLine($"{number} x {i} = {number * i}");
        }
    }
}
//Program to List Even Numbers
 using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        int number = int.Parse(Console.ReadLine());

        for (int i = 2; i <= number; i += 2)
        {
            Console.Write(i);
            if (i + 2 <= number)
                Console.Write(", ");
        }
    }
}
//Program to Compute Exponentiation
 using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter the base: ");
        int baseNumber = int.Parse(Console.ReadLine());

        Console.Write("Enter the exponent: ");
        int exponent = int.Parse(Console.ReadLine());

        int result = 1;
        for (int i = 0; i < exponent; i++)
        {
            result *= baseNumber;
        }

        Console.WriteLine($"Result: {result}");
    }
}
// Program to Reverse a Text String
 using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter a string: ");
        string input = Console.ReadLine();

        char[] charArray = input.ToCharArray();
        Array.Reverse(charArray);

        Console.WriteLine("Reversed: " + new string(charArray));
    }
}
//Program to Reverse an Integer Value
using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter an integer: ");
        int number = int.Parse(Console.ReadLine());

        int reversed = 0;
        while (number != 0)
        {
            int digit = number % 10;
            reversed = reversed * 10 + digit;
            number /= 10;
        }

        Console.WriteLine("Reversed: " + reversed);
    }
}
//Program to Find Longest Distance Between Matching Elements
 using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter the size of the array: ");
        int n = int.Parse(Console.ReadLine());
        
        int[] arr = new int[n];
        Console.WriteLine("Enter the elements of the array:");
        for (int i = 0; i < n; i++)
        {
            arr[i] = int.Parse(Console.ReadLine());
        }

        int maxDistance = 0;

        for (int i = 0; i < n; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                if (arr[i] == arr[j])
                {
                    maxDistance = Math.Max(maxDistance, j - i);
                }
            }
        }

        Console.WriteLine("Longest Distance: " + maxDistance);
    }
}
//Program to Reverse Words in a Sentence
using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter a sentence: ");
        string sentence = Console.ReadLine();

        string[] words = sentence.Split(' ');
        Array.Reverse(words);

        Console.WriteLine("Reversed Sentence: " + string.Join(" ", words));
    }
}

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
